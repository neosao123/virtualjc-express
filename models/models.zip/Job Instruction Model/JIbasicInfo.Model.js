// dont use this model
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
let JIbasicInfo = new Schema({
    orderNo: {
        type: String,
        required: true
    },
    priority: {
        type: Boolean
    },
    waiting: {
        type: Boolean
    },
    PM: {
        type: String
    },
    GR: {
        type: Boolean
    },
    KM: {
        type: String
    },
    WR: {
        type: Boolean,
        default: false,
    },
    internal: {
        type: Boolean
    },
    pickUp: {
        type: Schema.Types.Mixed
    },
    appointment: {
        type: Boolean
    },
    walkIn: {
        type: Boolean
    },
    receptionDate: {
        type: String
    },
    receptionTime: {
        type: String
    },
    receptionChanges: {
        type: String
    },
    deliveryDate: {
        type: String
    },
    deliveryTime: {
        tupe: String
    },
    deliveryChanges: {
        type: String
    },
    RepairOrderNo: {
        type: String
    },
    RepairDate: {
        type: String
    },
    name: {
        type: String
    },
    address: {
        type: String
    },
    mobileTeleNumber: {
        type: Schema.Types.Mixed,
    },
    homeTeleNumber: {
        type: Schema.Types.Mixed,
    },
    officeTeleNumber: {
        type: Schema.Types.Mixed,
    },
    cemail: {
        type: Schema.Types.Mixed,
    },
    others: {
        type: Schema.Types.Mixed,
    },
    vehicleRegNo: {
        type: String
    },
    modelYear: {
        type: String
    },
    modelCode: {
        type: String
    },
    vinNo: {
        type: String
    },
    colorCode: {
        type: String
    }
}, {
    timestamps: true
});

module.exports = mongoose.model("JIbasicInfo", JIbasicInfo);